# ID 87792916

def quicksort(example: list, left_border: int, right_border: int) -> None:
    if left_border >= right_border:
        return

    left, right = left_border, right_border
    pivot = example[left_border]

    while left <= right:
        while example[left] < pivot:
            left += 1
        while example[right] > pivot:
            right -= 1
        if left <= right:
            example[left], example[right] = example[right], example[left]
            left += 1
            right -= 1

    quicksort(example, left_border, right)
    quicksort(example, left, right_border)


if __name__ == '__main__':
    users_count = int(input())
    users_achievements = [[-int(y), int(z), str(x)] for x, y, z in
                          [input().split() for _ in range(users_count)]]
    quicksort(users_achievements, left_border=0,
              right_border=len(users_achievements) - 1)
    for data in users_achievements:
        print(data[2])
